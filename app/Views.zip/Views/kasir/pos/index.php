<?= $this->extend('layout/kasir_main'); ?>

<?php
$cart  = session()->get('cart') ?? [];
$total = 0;
foreach ($cart as $item) {
    $total += $item['qty'] * $item['harga_jual'];
}
?>

<?= $this->section('styles'); ?>
<!-- Tailwind CDN khusus halaman POS -->
<script src="https://cdn.tailwindcss.com"></script>
<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    brand: {
                        50: '#ecfdf3',
                        100: '#d1fadf',
                        500: '#22c55e',
                        600: '#16a34a',
                        700: '#15803d',
                    }
                },
                borderRadius: {
                    '2xl': '1.25rem',
                }
            }
        }
    }
</script>
<?= $this->endSection(); ?>

<?= $this->section('content'); ?>

<div class="space-y-5">
    <!-- Header POS -->
    <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
        <div>
            <p class="text-[11px] font-semibold tracking-[0.18em] text-slate-500 uppercase">
                POS Kasir
            </p>
            <h1 class="mt-1 text-2xl md:text-3xl font-bold text-slate-900">
                Toko Z&amp;Z &mdash; Point of Sale
            </h1>
            <p class="mt-1 text-sm text-slate-500">
                Scan / input barang, cek ringkasan cart, lalu selesaikan pembayaran dengan cepat.
            </p>
        </div>

        <div class="flex flex-wrap items-center gap-2">
            <div class="inline-flex items-center gap-2 rounded-full bg-slate-900 text-slate-50 px-3 py-1.5 text-[11px]">
                <span class="inline-flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>Mode kasir aktif</span>
            </div>
            <div class="inline-flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1.5 text-[11px] text-slate-700">
                <span><?= count($cart); ?> item</span>
                <span class="w-px h-3 bg-slate-300"></span>
                <span>Total: <strong>Rp <?= number_format($total, 0, ',', '.'); ?></strong></span>
            </div>
        </div>
    </div>

    <!-- Layout 2 kolom -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-5">
        <!-- KIRI: Scan & Pembayaran -->
        <div class="space-y-4">
            <!-- Scan / Input Barang -->
            <div class="rounded-2xl border border-slate-200 bg-white p-4 sm:p-5 shadow-sm">
                <div class="flex items-center justify-between gap-2 mb-3">
                    <div>
                        <p class="text-[11px] font-semibold tracking-[0.18em] text-slate-500 uppercase">
                            Scan / Input Barang
                        </p>
                        <h2 class="mt-1 text-base sm:text-lg font-semibold text-slate-900">
                            Tambahkan item ke keranjang
                        </h2>
                    </div>
                    <span class="hidden sm:inline-flex items-center rounded-full bg-slate-100 px-3 py-1 text-[11px] text-slate-600">
                        Gunakan barcode / ketik manual
                    </span>
                </div>

                <div class="space-y-3">
                    <!-- Tombol scan kamera (placeholder interaksi) -->
                    <button type="button"
                            id="btn-open-scanner"
                            class="w-full inline-flex items-center justify-center gap-2 rounded-xl border border-slate-300
                                   bg-slate-50 px-3 py-2 text-xs sm:text-sm font-medium text-slate-700 hover:bg-slate-100 transition">
                        <span>📷</span>
                        <span>Scan barcode dengan kamera</span>
                    </button>

                    <!-- Area scanner (bisa dipakai nanti kalau mau aktifkan html5-qrcode) -->
                    <div id="scanner-wrapper" class="mt-2 hidden rounded-xl border border-dashed border-slate-300 bg-slate-50 p-3">
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-[11px] font-semibold tracking-[0.18em] text-slate-500 uppercase">
                                Mode kamera
                            </span>
                            <button type="button"
                                    id="btn-close-scanner"
                                    class="text-[11px] text-slate-500 hover:text-slate-700">
                                Tutup
                            </button>
                        </div>
                        <div id="reader" class="w-full aspect-video rounded-lg bg-slate-900/90 flex items-center justify-center text-[11px] text-slate-200">
                            Area scanner kamera
                        </div>
                        <p class="mt-2 text-[11px] text-slate-500">
                            Ketika fitur scanner diaktifkan, barcode yang terbaca akan otomatis mengisi kolom barcode di bawah.
                        </p>
                    </div>

                    <!-- Form tambah item -->
                    <form action="<?= site_url('kasir/pos/addItem'); ?>" method="post" class="space-y-3">
                        <?= csrf_field() ?>

                        <div class="space-y-1">
                            <label class="block text-[11px] font-semibold tracking-[0.14em] text-slate-600 uppercase">
                                Barcode / Kode barang
                            </label>
                            <input type="text"
                                   name="barcode"
                                   id="barcode-input"
                                   autocomplete="off"
                                   autofocus
                                   class="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900
                                          placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500">
                        </div>

                        <div class="space-y-1">
                            <label class="block text-[11px] font-semibold tracking-[0.14em] text-slate-600 uppercase">
                                Qty
                            </label>
                            <input type="number"
                                   name="qty"
                                   min="1"
                                   value="1"
                                   required
                                   class="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900
                                          focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500">
                        </div>

                        <button type="submit"
                                class="w-full inline-flex items-center justify-center rounded-full bg-brand-600 hover:bg-brand-700
                                       px-4 py-2 text-xs sm:text-sm font-semibold text-white shadow-sm transition">
                            + Tambah ke cart
                        </button>
                    </form>
                </div>
            </div>

            <!-- Pembayaran -->
            <div class="rounded-2xl border border-slate-200 bg-white p-4 sm:p-5 shadow-sm">
                <div class="flex items-center justify-between gap-2 mb-3">
                    <div>
                        <p class="text-[11px] font-semibold tracking-[0.18em] text-slate-500 uppercase">
                            Pembayaran
                        </p>
                        <h2 class="mt-1 text-base sm:text-lg font-semibold text-slate-900">
                            Ringkasan & proses pembayaran
                        </h2>
                    </div>
                    <?php if (! empty($cart)): ?>
                        <div class="text-right">
                            <p class="text-[11px] text-slate-500 uppercase tracking-[0.14em]">Total</p>
                            <p class="text-lg font-bold text-emerald-600">
                                Rp <?= number_format($total, 0, ',', '.'); ?>
                            </p>
                        </div>
                    <?php endif; ?>
                </div>

                <form action="<?= site_url('kasir/pos/checkout'); ?>" method="post" class="space-y-3">
                    <?= csrf_field() ?>

                    <div class="space-y-1">
                        <label class="block text-[11px] font-semibold tracking-[0.14em] text-slate-600 uppercase">
                            Total yang harus dibayar
                        </label>
                        <div class="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 flex items-center justify-between">
                            <span class="text-[11px] text-slate-500">Grand total</span>
                            <span class="font-semibold">
                                Rp <?= number_format($total, 0, ',', '.'); ?>
                            </span>
                        </div>
                    </div>

                    <div class="space-y-1">
                        <label class="block text-[11px] font-semibold tracking-[0.14em] text-slate-600 uppercase">
                            Metode pembayaran
                        </label>
                        <select name="payment_method"
                                id="payment_method"
                                class="w-full rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900
                                       focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-brand-500"
                                required>
                            <option value="cash">Tunai</option>
                            <option value="qris">QRIS</option>
                        </select>
                    </div>

                    <!-- Tunai -->
                    <div class="space-y-1" id="amountPaidGroup">
                        <label class="block text-[11px] font-semibold tracking-[0.14em] text-slate-600 uppercase">
                            Nominal diterima (Tunai)
                        </label>
                        <div class="flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-3 py-2">
                            <span class="text-xs text-slate-500">Rp</span>
                            <input
                                type="number"
                                step="0.01"
                                name="amount_paid"
                                id="amount_paid"
                                class="w-full bg-transparent text-sm text-slate-900 focus:outline-none"
                                value="<?= $total; ?>">
                        </div>
                        <p class="text-[11px] text-slate-500">
                            Masukkan nominal uang yang diterima dari pelanggan.
                        </p>
                    </div>

                    <!-- QRIS -->
                    <div id="qris-section" class="hidden space-y-2">
                        <div class="rounded-xl border border-dashed border-emerald-300 bg-emerald-50/50 p-3">
                            <p class="text-xs font-medium text-emerald-800 mb-1">
                                QRIS demo
                            </p>
                            <div class="flex flex-col sm:flex-row sm:items-center gap-3">
                                <div id="qris-qrcode"
                                     class="h-28 w-28 rounded-lg bg-white border border-emerald-200 flex items-center justify-center text-[11px] text-slate-400">
                                    QR
                                </div>
                                <div class="text-[11px] text-slate-600 space-y-1">
                                    <p>
                                        Scan QR ini dengan aplikasi pembayaran untuk membayar
                                        <span class="font-semibold text-slate-900">
                                            Rp <?= number_format($total, 0, ',', '.'); ?>
                                        </span>
                                    </p>
                                    <p>
                                        ID Transaksi:
                                        <span id="qris-txid" class="font-mono text-xs font-semibold text-slate-900">
                                            -
                                        </span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="submit"
                            class="w-full inline-flex items-center justify-center rounded-full
                                   bg-emerald-600 hover:bg-emerald-700 px-4 py-2 text-xs sm:text-sm
                                   font-semibold text-white shadow-sm transition disabled:opacity-50"
                            <?= empty($cart) ? 'disabled' : ''; ?>>
                        Selesaikan transaksi &amp; cetak struk
                    </button>
                    <p class="text-[11px] text-slate-500">
                        Setelah transaksi tersimpan, sistem akan mengarahkan ke halaman struk.
                    </p>
                </form>
            </div>
        </div>

        <!-- KANAN: Cart -->
        <div class="rounded-2xl border border-slate-200 bg-white p-4 sm:p-5 shadow-sm flex flex-col h-full">
            <div class="flex items-center justify-between gap-2 mb-3">
                <div>
                    <p class="text-[11px] font-semibold tracking-[0.18em] text-slate-500 uppercase">
                        Cart
                    </p>
                    <h2 class="mt-1 text-base sm:text-lg font-semibold text-slate-900">
                        Daftar item di keranjang
                    </h2>
                </div>
                <?php if (! empty($cart)): ?>
                    <span class="inline-flex items-center rounded-full bg-slate-100 px-3 py-1 text-[11px] text-slate-600">
                        <?= count($cart); ?> item • Rp <?= number_format($total, 0, ',', '.'); ?>
                    </span>
                <?php endif; ?>
            </div>

            <div class="flex-1 overflow-hidden">
                <div class="h-full overflow-auto rounded-xl border border-slate-100">
                    <table class="min-w-full text-xs sm:text-sm">
                        <thead class="bg-slate-50">
                        <tr class="text-[11px] uppercase tracking-[0.16em] text-slate-500">
                            <th class="px-3 py-2 text-left">Barcode</th>
                            <th class="px-3 py-2 text-left">Nama</th>
                            <th class="px-3 py-2 text-center">Qty</th>
                            <th class="px-3 py-2 text-right">Harga</th>
                            <th class="px-3 py-2 text-right">Subtotal</th>
                        </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                        <?php if (! empty($cart)): ?>
                            <?php foreach ($cart as $item): ?>
                                <tr class="hover:bg-slate-50/80">
                                    <td class="px-3 py-2 align-middle">
                                        <span class="inline-flex items-center rounded-full bg-slate-100 px-2 py-0.5 text-[11px] text-slate-700">
                                            <?= esc($item['barcode']); ?>
                                        </span>
                                    </td>
                                    <td class="px-3 py-2 align-middle text-slate-800">
                                        <?= esc($item['nama']); ?>
                                    </td>
                                    <td class="px-3 py-2 align-middle text-center">
                                        <?= (int) $item['qty']; ?>
                                    </td>
                                    <td class="px-3 py-2 align-middle text-right text-slate-700">
                                        Rp <?= number_format($item['harga_jual'], 0, ',', '.'); ?>
                                    </td>
                                    <td class="px-3 py-2 align-middle text-right font-semibold text-slate-900">
                                        Rp <?= number_format($item['qty'] * $item['harga_jual'], 0, ',', '.'); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="px-3 py-6 text-center text-[11px] sm:text-sm text-slate-500">
                                    Keranjang masih kosong.  
                                    Tambahkan barang dari sisi kiri terlebih dahulu.
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                        <?php if (! empty($cart)): ?>
                            <tfoot class="border-t border-slate-100 bg-slate-50/60">
                            <tr>
                                <th colspan="4" class="px-3 py-2 text-right text-[11px] uppercase tracking-[0.16em] text-slate-500">
                                    Total
                                </th>
                                <th class="px-3 py-2 text-right text-sm font-bold text-emerald-600">
                                    Rp <?= number_format($total, 0, ',', '.'); ?>
                                </th>
                            </tr>
                            </tfoot>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>

<?= $this->section('scripts'); ?>
<script>
    // Toggle scanner wrapper (UI saja, logic scan bisa ditambah kemudian)
    const btnOpenScanner = document.getElementById('btn-open-scanner');
    const btnCloseScanner = document.getElementById('btn-close-scanner');
    const scannerWrapper = document.getElementById('scanner-wrapper');

    if (btnOpenScanner && btnCloseScanner && scannerWrapper) {
        btnOpenScanner.addEventListener('click', () => {
            scannerWrapper.classList.remove('hidden');
        });
        btnCloseScanner.addEventListener('click', () => {
            scannerWrapper.classList.add('hidden');
        });
    }

    // Logika simple QRIS vs Tunai
    const paymentSelect   = document.getElementById('payment_method');
    const amountPaidGroup = document.getElementById('amountPaidGroup');
    const amountPaidInput = document.getElementById('amount_paid');
    const qrisSection     = document.getElementById('qris-section');
    const qrisTxIdSpan    = document.getElementById('qris-txid');
    const totalAmount     = <?= (float) $total; ?>;

    function generateTxId() {
        const now = new Date();
        const pad = (n) => n.toString().padStart(2, '0');
        const ts =
            now.getFullYear().toString() +
            pad(now.getMonth() + 1) +
            pad(now.getDate()) +
            pad(now.getHours()) +
            pad(now.getMinutes()) +
            pad(now.getSeconds());
        return 'TX' + ts;
    }

    function updatePaymentUI() {
        if (!paymentSelect) return;

        if (paymentSelect.value === 'qris') {
            amountPaidGroup.classList.add('hidden');
            if (amountPaidInput) {
                amountPaidInput.value = totalAmount;
            }
            if (qrisSection) {
                qrisSection.classList.remove('hidden');
            }
            if (qrisTxIdSpan) {
                qrisTxIdSpan.textContent = generateTxId();
            }
        } else {
            amountPaidGroup.classList.remove('hidden');
            if (qrisSection) {
                qrisSection.classList.add('hidden');
            }
            if (qrisTxIdSpan) {
                qrisTxIdSpan.textContent = '-';
            }
        }
    }

    if (paymentSelect) {
        paymentSelect.addEventListener('change', updatePaymentUI);
        updatePaymentUI();
    }
</script>
<?= $this->endSection(); ?>
