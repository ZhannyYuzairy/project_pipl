<?= $this->extend('layout/kasir_main'); ?>

<?= $this->section('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="text-center mb-3">
                    <h5 class="mb-0">Toko Z&amp;Z</h5>
                    <small class="text-muted">Struk Pembelian</small>
                </div>

                <div class="d-flex justify-content-between small mb-2">
                    <span>Invoice</span>
                    <span><?= esc($sale['invoice_no']); ?></span>
                </div>
                <div class="d-flex justify-content-between small mb-2">
                    <span>Tanggal</span>
                    <span><?= esc($sale['sale_date']); ?></span>
                </div>
                <div class="d-flex justify-content-between small mb-3">
                    <span>Kasir</span>
                    <span><?= esc($kasir['nama'] ?? ''); ?></span>
                </div>

                <hr>

                <table class="table table-sm mb-2">
                    <thead>
                    <tr>
                        <th>Produk</th>
                        <th class="text-center">Qty</th>
                        <th class="text-end">Harga</th>
                        <th class="text-end">Subtotal</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td>
                                <?= esc($item['nama']); ?><br>
                                <small class="text-muted"><?= esc($item['barcode']); ?></small>
                            </td>
                            <td class="text-center"><?= $item['qty']; ?> <?= esc($item['satuan']); ?></td>
                            <td class="text-end">Rp <?= number_format($item['price'], 0, ',', '.'); ?></td>
                            <td class="text-end">Rp <?= number_format($item['subtotal'], 0, ',', '.'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

                <hr>

                <div class="d-flex justify-content-between small mb-1">
                    <span>Total</span>
                    <strong>Rp <?= number_format($sale['total_amount'], 0, ',', '.'); ?></strong>
                </div>
                <div class="d-flex justify-content-between small mb-1">
                    <span>Bayar (<?= strtoupper($sale['payment_method']); ?>)</span>
                    <span>Rp <?= number_format($sale['amount_paid'], 0, ',', '.'); ?></span>
                </div>
                <div class="d-flex justify-content-between small mb-3">
                    <span>Kembalian</span>
                    <span>Rp <?= number_format($sale['change_amount'], 0, ',', '.'); ?></span>
                </div>

                <div class="text-center small text-muted mt-3">
                    Terima kasih telah berbelanja di Toko Z&amp;Z
                </div>

                <div class="mt-3 d-flex justify-content-between">
                    <a href="<?= site_url('kasir/pos'); ?>" class="btn btn-outline-secondary btn-sm">
                        Kembali ke POS
                    </a>
                    <button type="button" class="btn btn-primary btn-sm" onclick="window.print();">
                        Cetak Struk
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>
