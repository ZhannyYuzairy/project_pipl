<?= $this->extend('layout/kasir_main'); ?>

<?= $this->section('styles'); ?>
<!-- Tailwind CDN khusus halaman kasir -->
<script src="https://cdn.tailwindcss.com"></script>
<script>
    tailwind.config = {
        theme: {
            extend: {
                colors: {
                    brand: {
                        50: '#ecfdf3',
                        100: '#d1fadf',
                        500: '#22c55e',
                        600: '#16a34a',
                        700: '#15803d',
                    }
                },
                borderRadius: {
                    'xl': '0.9rem',
                    '2xl': '1.25rem',
                }
            }
        }
    }
</script>
<?= $this->endSection(); ?>

<?= $this->section('content'); ?>

<?php
$namaKasir   = session()->get('nama') ?? 'Kasir';
$totalHariIni = $totalPenjualanKasir ?? 0;
$trxHariIni   = $totalTransaksiKasir ?? 0;
$avgTicket    = $trxHariIni > 0 ? $totalHariIni / $trxHariIni : 0;
?>

<div class="space-y-5">
    <!-- Header -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
            <p class="text-xs font-semibold tracking-[0.28em] text-slate-500 uppercase">
                Dashboard Kasir
            </p>
            <h1 class="mt-1 text-2xl md:text-3xl font-bold text-slate-900">
                Halo, <?= esc($namaKasir); ?> 👋
            </h1>
            <p class="mt-1 text-sm text-slate-500">
                Pantau penjualan harian & buka POS dengan cepat.
            </p>
        </div>

        <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <div class="rounded-full bg-emerald-50 border border-emerald-100 px-3 py-1.5 text-xs text-emerald-700 flex items-center gap-1">
                <span class="inline-flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Shift aktif</span>
            </div>
            <a href="<?= site_url('kasir/pos'); ?>"
               class="inline-flex items-center justify-center rounded-full bg-brand-600 hover:bg-brand-700
                      text-white text-xs sm:text-sm font-semibold px-4 py-2 shadow-sm transition">
                🚀 Buka POS Sekarang
            </a>
        </div>
    </div>

    <!-- Kartu ringkasan -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <!-- Total penjualan -->
        <div class="rounded-2xl border border-slate-200 bg-white p-4 flex flex-col justify-between">
            <div class="flex items-center justify-between gap-2">
                <div>
                    <p class="text-[11px] font-semibold tracking-[0.18em] text-slate-500 uppercase">
                        Penjualan hari ini
                    </p>
                    <p class="mt-2 text-2xl font-bold text-slate-900">
                        Rp <?= number_format($totalHariIni, 0, ',', '.'); ?>
                    </p>
                </div>
                <div class="h-10 w-10 rounded-full bg-emerald-50 flex items-center justify-center">
                    <span class="text-lg">💰</span>
                </div>
            </div>
            <p class="mt-2 text-[11px] text-slate-500">
                Berdasarkan semua transaksi yang kamu input hari ini.
            </p>
        </div>

        <!-- Jumlah transaksi -->
        <div class="rounded-2xl border border-slate-200 bg-white p-4 flex flex-col justify-between">
            <div class="flex items-center justify-between gap-2">
                <div>
                    <p class="text-[11px] font-semibold tracking-[0.18em] text-slate-500 uppercase">
                        Jumlah transaksi
                    </p>
                    <p class="mt-2 text-2xl font-bold text-slate-900">
                        <?= (int) $trxHariIni; ?>
                    </p>
                </div>
                <div class="h-10 w-10 rounded-full bg-sky-50 flex items-center justify-center">
                    <span class="text-lg">🧾</span>
                </div>
            </div>
            <p class="mt-2 text-[11px] text-slate-500">
                Total invoice yang tercatat hari ini.
            </p>
        </div>

        <!-- Average ticket size -->
        <div class="rounded-2xl border border-slate-200 bg-white p-4 flex flex-col justify-between">
            <div class="flex items-center justify-between gap-2">
                <div>
                    <p class="text-[11px] font-semibold tracking-[0.18em] text-slate-500 uppercase">
                        Rata-rata per transaksi
                    </p>
                    <p class="mt-2 text-2xl font-bold text-slate-900">
                        Rp <?= number_format($avgTicket, 0, ',', '.'); ?>
                    </p>
                </div>
                <div class="h-10 w-10 rounded-full bg-violet-50 flex items-center justify-center">
                    <span class="text-lg">📊</span>
                </div>
            </div>
            <p class="mt-2 text-[11px] text-slate-500">
                Estimasi nilai rata-rata setiap transaksi.
            </p>
        </div>
    </div>

    <!-- Transaksi terakhir -->
    <div class="rounded-2xl border border-slate-200 bg-white p-4 sm:p-5">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
            <div>
                <p class="text-[11px] font-semibold tracking-[0.18em] text-slate-500 uppercase">
                    Transaksi terakhir
                </p>
                <h2 class="mt-1 text-base sm:text-lg font-semibold text-slate-900">
                    Beberapa transaksi terakhir yang kamu input
                </h2>
            </div>
            <span class="inline-flex items-center rounded-full bg-slate-100 px-3 py-1 text-[11px] text-slate-600">
                Maks 5 transaksi terakhir hari ini
            </span>
        </div>

        <?php if (! empty($transaksiTerakhir)): ?>
            <div class="overflow-x-auto">
                <table class="min-w-full text-xs sm:text-sm">
                    <thead>
                    <tr class="border-b border-slate-100 bg-slate-50 text-[11px] uppercase tracking-[0.16em] text-slate-500">
                        <th class="px-3 py-2 text-left">Invoice</th>
                        <th class="px-3 py-2 text-left">Tanggal</th>
                        <th class="px-3 py-2 text-right">Total</th>
                        <th class="px-3 py-2 text-left">Metode</th>
                    </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                    <?php foreach ($transaksiTerakhir as $trx): ?>
                        <tr class="hover:bg-slate-50/80">
                            <td class="px-3 py-2">
                                <span class="inline-flex items-center rounded-full bg-slate-100 px-2 py-0.5 text-[11px] text-slate-700">
                                    <?= esc($trx['invoice'] ?? ''); ?>
                                </span>
                            </td>
                            <td class="px-3 py-2 text-slate-700">
                                <?= esc($trx['sale_date'] ?? ''); ?>
                            </td>
                            <td class="px-3 py-2 text-right font-semibold text-slate-900">
                                Rp <?= isset($trx['grand_total']) ? number_format($trx['grand_total'], 0, ',', '.') : '0'; ?>
                            </td>
                            <td class="px-3 py-2">
                                <?php $pm = strtolower($trx['payment_method'] ?? 'cash'); ?>
                                <span class="inline-flex items-center rounded-full px-2 py-0.5 text-[11px]
                                             <?= $pm === 'qris'
                                                 ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                                                 : 'bg-slate-100 text-slate-700 border border-slate-200'; ?>">
                                    <?= strtoupper($pm); ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="rounded-xl border border-dashed border-slate-200 bg-slate-50 p-4 text-xs sm:text-sm text-slate-500">
                Belum ada transaksi yang kamu input hari ini.  
                Mulai dari tombol <span class="font-semibold text-slate-700">"Buka POS Sekarang"</span> di atas.
            </div>
        <?php endif; ?>
    </div>
</div>

<?= $this->endSection(); ?>
