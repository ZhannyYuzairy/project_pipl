<?php

namespace App\Controllers\Kasir;

use App\Controllers\BaseController;
use App\Models\ProductModel;
use App\Models\SaleModel;
use App\Models\SaleItemModel;
use App\Models\UserModel;

class Pos extends BaseController
{
    protected $productModel;
    protected $saleModel;
    protected $saleItemModel;
    protected $userModel;

    public function __construct()
    {
        $this->productModel  = new ProductModel();
        $this->saleModel     = new SaleModel();
        $this->saleItemModel = new SaleItemModel();
        $this->userModel     = new UserModel();
    }

    public function index()
    {
        $data = [
            'title' => 'POS - Toko Z&Z',
        ];

        return view('kasir/pos/index', $data);
    }

    public function addItem()
    {
        $barcode = $this->request->getPost('barcode');
        $qty     = (int) $this->request->getPost('qty');

        if (! $barcode || $qty <= 0) {
            return redirect()
                ->back()
                ->with('error', 'Barcode dan qty harus diisi.');
        }

        $product = $this->productModel
            ->where('barcode', $barcode)
            ->first();

        if (! $product) {
            return redirect()
                ->back()
                ->with('error', 'Produk dengan barcode tersebut tidak ditemukan.');
        }

        // Ambil cart dari session
        $cart = session()->get('cart') ?? [];

        $productId = $product['id'];

        if (isset($cart[$productId])) {
            $cart[$productId]['qty'] += $qty;
        } else {
            $cart[$productId] = [
                'product_id' => $productId,
                'barcode'    => $product['barcode'],
                'nama'       => $product['nama'],
                'qty'        => $qty,
                'harga_beli' => (float) $product['harga_beli'],
                'harga_jual' => (float) $product['harga_jual'],
            ];
        }

        session()->set('cart', $cart);

        return redirect()
            ->to(site_url('kasir/pos'))
            ->with('success', 'Produk berhasil ditambahkan ke cart.');
    }

    public function checkout()
    {
        $cart = session()->get('cart') ?? [];

        if (empty($cart)) {
            return redirect()
                ->back()
                ->with('error', 'Cart masih kosong.');
        }

        $paymentMethod = $this->request->getPost('payment_method') ?? 'cash';
        $amountPaid    = (float) $this->request->getPost('amount_paid');

        // Hitung total & total cost
        $totalAmount = 0;
        $totalCost   = 0;

        foreach ($cart as $item) {
            $lineTotal = $item['qty'] * $item['harga_jual'];
            $lineCost  = $item['qty'] * $item['harga_beli'];

            $totalAmount += $lineTotal;
            $totalCost   += $lineCost;
        }

        if ($paymentMethod === 'cash') {
            if ($amountPaid < $totalAmount) {
                return redirect()
                    ->back()
                    ->with('error', 'Uang yang diterima kurang dari total belanja.');
            }
        } else {
            // QRIS → dianggap dibayar pas
            $amountPaid = $totalAmount;
        }

        $change = $amountPaid - $totalAmount;

        $db = \Config\Database::connect();
        $db->transStart();

        $userId    = session()->get('user_id');
        $invoiceNo = 'INV' . date('YmdHis');

        // Simpan ke tabel sales
        $saleId = $this->saleModel->insert([
            'invoice_no'     => $invoiceNo,
            'user_id'        => $userId,
            'sale_date'      => date('Y-m-d H:i:s'),
            'total_amount'   => $totalAmount,
            'total_cost'     => $totalCost,
            'payment_method' => $paymentMethod,
            'amount_paid'    => $amountPaid,
            'change_amount'  => $change,
        ]);

        // Simpan ke sale_items + update stok
        foreach ($cart as $item) {
            $this->saleItemModel->insert([
                'sale_id'       => $saleId,
                'product_id'    => $item['product_id'],
                'qty'           => $item['qty'],
                'price'         => $item['harga_jual'],
                'cost'          => $item['harga_beli'],
                'subtotal'      => $item['qty'] * $item['harga_jual'],
                'subtotal_cost' => $item['qty'] * $item['harga_beli'],
            ]);

            // Update stok (tanpa cek stok, bisa ditambah kemudian)
            $this->productModel
                ->set('stok', 'stok - ' . (int) $item['qty'], false)
                ->where('id', $item['product_id'])
                ->update();
        }

        $db->transComplete();

        if (! $db->transStatus()) {
            return redirect()
                ->back()
                ->with('error', 'Terjadi kesalahan saat menyimpan transaksi.');
        }

        // kosongkan cart
        session()->remove('cart');

        return redirect()
            ->to(site_url('kasir/pos/struk/' . $saleId));
    }

    public function struk($saleId = null)
    {
        $sale = $this->saleModel->find($saleId);

        if (! $sale) {
            return redirect()
                ->to(site_url('kasir/pos'))
                ->with('error', 'Transaksi tidak ditemukan.');
        }

        $kasir = $this->userModel->find($sale['user_id']);

        $items = $this->saleItemModel
            ->select('sale_items.*, products.nama, products.barcode, products.satuan')
            ->join('products', 'products.id = sale_items.product_id')
            ->where('sale_id', $saleId)
            ->findAll();

        $data = [
            'sale'  => $sale,
            'kasir' => $kasir,
            'items' => $items,
            'title' => 'Struk Transaksi',
        ];

        // nanti kamu bisa buat view baru: kasir/pos/struk.php
        return view('kasir/pos/struk', $data);
    }
}
