<?php

namespace App\Controllers\Kasir;

use App\Controllers\BaseController;
use App\Models\SaleModel;

class Dashboard extends BaseController
{
    protected $saleModel;

    public function __construct()
    {
        $this->saleModel = new SaleModel();
    }

    public function index()
    {
        $userId = session()->get('user_id');
        $today  = date('Y-m-d');

        // total penjualan kasir hari ini
        $row = $this->saleModel
            ->selectSum('total_amount', 'totalPenjualanKasir')
            ->where('user_id', $userId)
            ->where('DATE(sale_date)', $today)
            ->first();

        $totalPenjualanKasir = $row['totalPenjualanKasir'] ?? 0;

        // jumlah transaksi kasir hari ini
        $totalTransaksiKasir = $this->saleModel
            ->where('user_id', $userId)
            ->where('DATE(sale_date)', $today)
            ->countAllResults();

        // transaksi terakhir kasir ini
        $transaksiTerakhir = $this->saleModel
            ->where('user_id', $userId)
            ->orderBy('sale_date', 'DESC')
            ->limit(5)
            ->findAll();

        $data = [
            'title'                 => 'Dashboard Kasir',
            'totalPenjualanKasir'   => $totalPenjualanKasir,
            'totalTransaksiKasir'   => $totalTransaksiKasir,
            'transaksiTerakhir'     => $transaksiTerakhir,
        ];

        return view('kasir/dashboard', $data);
    }
}
